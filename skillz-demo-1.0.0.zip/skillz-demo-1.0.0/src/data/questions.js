const questions = [
    {
        "number": 1,
        "question": "Hoe goed was je in Javascript?",
        "rating": 0,
        'previous': "/",
        "next": "/vragen/2",
    },
    {
        "number": 2,
        "question": "Hoe goed ben je nu in Javascript?",
        "rating": 0,
        "previous": "/vragen/1",
        "next": "/vragen/3",
    },
    {
        "number": 3,
        "question": "Hoe goed was je in HTML?",
        "rating": 0,
        "previous": "/vragen/2",
        "next": "/vragen/4",
    },
    {
        "number": 4,
        "question": "Hoe goed ben je nu in HTML?",
        "rating": 0,
        'previous': "/vragen/3",
        "next": "/vragen/5",

    },
    {
        "number": 5,
        "question": "Hoe goed was je in CSS?",
        "rating": 0,
        'previous': "/vragen/4",
        "next": "/vragen/6",

    },
    {
        "number": 6,
        "question": "Hoe goed ben je nu in CSS?",
        "rating": 0,
        'previous': "/vragen/5",
        "next": "/vragen/7",

    },
    {
        "number": 7,
        "question": "Hoe goed was je in React?",
        "rating": 0,
        'previous': "/vragen/6",
        "next": "/vragen/8",

    },
    {
        "number": 8,
        "question": "Hoe goed ben je nu in React?",
        "rating": 0,
        'previous': "/vragen/7",
        "next": "/outro",
        "last": true,
    },
];

export default questions;